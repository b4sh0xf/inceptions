<?php

echo "oi";
